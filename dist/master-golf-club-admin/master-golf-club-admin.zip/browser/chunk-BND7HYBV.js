import{a as me}from"./chunk-HBTOLUYY.js";import"./chunk-GFV7M3J3.js";import{a as fe}from"./chunk-C4ZII7PO.js";import{Ba as K,Ca as Q,Da as f,Ea as W,Fa as X,H as q,Ka as Y,M as B,N as O,Na as Z,Oa as ee,Pa as te,Q as R,Qa as ie,Ra as ne,Ua as re,Va as ae,Wa as oe,Xa as le,Z as V,_ as A,aa as G,ba as $,c as k,d as D,da as j,ea as z,f as L,ha as H,ia as J,o as U,q as T}from"./chunk-MQQCFL5Y.js";import{$b as e,Hb as t,Ib as i,Jb as u,Kb as E,Lb as P,Nb as I,Pb as y,Qb as x,Za as F,ab as a,bb as _,bc as p,ga as M,ic as w,ra as S,rb as s,sa as C,xb as o}from"./chunk-7U6K5JTK.js";import{f as pe,k as b}from"./chunk-AAPNLDO3.js";var N=pe(fe());function xe(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("firstName"),`
            `)}}function ue(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("lastName"),`
            `)}}function he(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("email"),`
            `)}}function be(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("phoneNumber"),`
            `)}}function ge(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("alternatePhoneNumber"),`
            `)}}function ye(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("dateOfBirth"),`
            `)}}function ve(n,d){if(n&1&&(t(0,"option",60),e(1),i()),n&2){let m=d.$implicit;o("value",m.id),a(),p(`
                `,m.genderName,`
              `)}}function _e(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("gender"),`
            `)}}function Se(n,d){if(n&1&&(t(0,"option",60),e(1),i()),n&2){let m=d.$implicit;o("value",m.id),a(),p(`
                `,m.countryName,`
              `)}}function Ce(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("nationality"),`
            `)}}function Fe(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("address"),`
            `)}}function Ee(n,d){if(n&1&&(t(0,"option",60),e(1),i()),n&2){let m=d.$implicit;o("value",m.id),a(),p(`
                `,m.planName,`
              `)}}function Pe(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("plan"),`
            `)}}function Ie(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("membershipStartDate"),`
            `)}}function Ne(n,d){if(n&1&&(t(0,"option",60),e(1),i()),n&2){let m=d.$implicit;o("value",m.id),a(),p(`
                `,m.statusName,`
              `)}}function Me(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("paymentStatus"),`
            `)}}function we(n,d){if(n&1&&(t(0,"option",60),e(1),i()),n&2){let m=d.$implicit;o("value",m.id),a(),p(`
                `,m.methodName,`
              `)}}function ke(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("paymentMethod"),`
            `)}}function De(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("emergencyContactName"),`
            `)}}function Le(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("emergencyContactPhone"),`
            `)}}function Ue(n,d){if(n&1&&(t(0,"c-form-feedback",59),e(1),i()),n&2){let m=x();o("valid",!1),a(),p(`
              `,m.getErrorMessage("emergencyContactRelation"),`
            `)}}function Te(n,d){if(n&1){let m=I();t(0,"div",61),e(1,`
                `),u(2,"img",62),e(3,`
                `),t(4,"button",63),y("click",function(){S(m);let c=x();return C(c.removeFile("profile"))}),e(5,`
                  Remove Photo
                `),i(),e(6,`
              `),i()}if(n&2){let m=x();a(2),o("src",m.profilePhotoPreview,F)}}function qe(n,d){if(n&1&&(E(0),e(1,`
                  `),u(2,"img",65),e(3,`
                `),P()),n&2){let m=x(2);a(2),o("src",m.idProofPreview,F)}}function Be(n,d){n&1&&(E(0),e(1,`
                  `),t(2,"div",66),e(3,`
                    ID Proof document uploaded
                  `),i(),e(4,`
                `),P())}function Oe(n,d){if(n&1){let m=I();t(0,"div",61),e(1,`
                `),s(2,qe,4,1,"ng-container",64),e(3,`
                `),s(4,Be,5,0,"ng-container",64),e(5,`
                `),t(6,"button",63),y("click",function(){S(m);let c=x();return C(c.removeFile("idProof"))}),e(7,`
                  Remove ID Proof
                `),i(),e(8,`
              `),i()}if(n&2){let m=x();a(2),o("ngIf",m.idProofPreview.toString().includes("data:image")),a(2),o("ngIf",!m.idProofPreview.toString().includes("data:image"))}}var Qe=(()=>{let d=class d{constructor(l,c,r,h){this.fb=l,this.router=c,this.route=r,this.memberService=h,this.loading=!1,this.submitted=!1,this.customStylesValidated=!1,this.memberId="",this.genders=[],this.nationalities=[],this.plans=[],this.paymentStatuses=[],this.paymentMethods=[],this.profilePhotoFile=null,this.idProofFile=null,this.profilePhotoPreview=null,this.idProofPreview=null,this.existingProfilePhoto=null,this.existingIdProof=null,this.initializeForm()}get f(){return this.memberForm.controls}initializeForm(){let l=new Date().toISOString().split("T")[0];this.memberForm=this.fb.group({firstName:["",[f.required,f.minLength(2)]],lastName:["",[f.required,f.minLength(2)]],email:["",[f.required,f.email]],phoneNumber:["",[f.required,f.pattern("^[0-9]{10}$")]],alternatePhoneNumber:["",[f.pattern("^[0-9]{10}$")]],address:["",[f.required,f.minLength(10)]],dateOfBirth:["",[f.required]],gender:["",[f.required]],nationality:["",[f.required]],plan:["",[f.required]],golfClubId:[{value:"",disabled:!0}],membershipStartDate:[l,[f.required]],membershipEndDate:[""],emergencyContactName:["",[f.required]],emergencyContactPhone:["",[f.required,f.pattern("^[0-9]{10}$")]],emergencyContactRelation:["",[f.required]],paymentStatus:["",[f.required]],paymentMethod:["",[f.required]],referredBy:[""],handicap:[!1]})}ngOnInit(){return b(this,null,function*(){try{this.route.params.subscribe(l=>{this.memberId=l.id,this.loadMemberData(this.memberId)})}catch{yield this.showError("An error occurred during initialization.")}})}loadGenders(){return b(this,null,function*(){try{let l=yield this.memberService.getGender();l?.data&&(this.genders=l.data)}catch(l){throw l}})}loadNationalities(){return b(this,null,function*(){try{let l=yield this.memberService.getNationality();l?.data&&(this.nationalities=l.data)}catch(l){throw l}})}loadPlans(){return b(this,null,function*(){try{let l=yield this.memberService.getPlan();l?.data&&(this.plans=l.data)}catch(l){throw l}})}loadPaymentStatuses(){return b(this,null,function*(){try{let l=yield this.memberService.getPaymentStatus();l?.data&&(this.paymentStatuses=l.data)}catch(l){throw l}})}loadPaymentMethods(){return b(this,null,function*(){try{let l=yield this.memberService.getPaymentMethod();l?.data&&(this.paymentMethods=l.data)}catch(l){throw l}})}loadMemberData(l){return b(this,null,function*(){try{yield Promise.all([this.loadGenders(),this.loadNationalities(),this.loadPlans(),this.loadPaymentStatuses(),this.loadPaymentMethods()]);let c=yield this.memberService.listMember(l);if(c?.data?.code===1&&c.data.data?.length>0){let r=c.data.data[0],h=this.genders.find(g=>g.genderName.toLowerCase()===r.gender.toLowerCase())?.id,v=this.nationalities.find(g=>g.countryName.toLowerCase()===r.nationality.toLowerCase())?.id,de=this.plans.find(g=>g.planName.toLowerCase()===r.plan.toLowerCase())?.id,ce=this.paymentStatuses.find(g=>g.statusName.toLowerCase()===r.paymentStatus.toLowerCase())?.id,se=this.paymentMethods.find(g=>g.methodName.toLowerCase()===r.paymentMethod.toLowerCase())?.id;this.memberForm.patchValue({firstName:r.firstName,lastName:r.lastName,email:r.email,phoneNumber:r.phoneNumber,alternatePhoneNumber:r.alternatePhoneNumber||"",address:r.address,dateOfBirth:r.dateOfBirth,gender:h,nationality:v,plan:de,golfClubId:r.golfClubId,membershipStartDate:r.membershipStartDate,membershipEndDate:r.membershipEndDate,emergencyContactName:r.emergencyContactName,emergencyContactPhone:r.emergencyContactPhone,emergencyContactRelation:r.emergencyContactRelation,paymentStatus:ce,paymentMethod:se,referredBy:r.referredBy||"",handicap:r.handicap}),r.profilePhoto&&(this.existingProfilePhoto=r.profilePhoto,this.profilePhotoPreview=r.profilePhoto),r.idProof&&(this.existingIdProof=r.idProof,this.idProofPreview=r.idProof)}}catch{yield this.showError("Failed to load member data.")}})}onFileSelected(l,c){let r=l.target.files[0];r&&(c==="profile"?(this.profilePhotoFile=r,this.readFile(r).then(h=>{this.profilePhotoPreview=h})):(this.idProofFile=r,this.readFile(r).then(h=>{this.idProofPreview=h})))}readFile(l){return new Promise(c=>{let r=new FileReader;r.onload=h=>c(h.target?.result||""),r.readAsDataURL(l)})}removeFile(l){l==="profile"?(this.profilePhotoFile=null,this.profilePhotoPreview=null,this.existingProfilePhoto=null):(this.idProofFile=null,this.idProofPreview=null,this.existingIdProof=null)}onSubmit(){return b(this,null,function*(){if(this.customStylesValidated=!0,this.submitted=!0,this.memberForm.invalid){Object.values(this.memberForm.controls).forEach(l=>{l.invalid&&l.markAsTouched()});return}this.loading=!0;try{let l=new FormData;Object.keys(this.memberForm.value).forEach(r=>{let h=this.memberForm.get(r)?.value;h!=null&&l.append(r,h)}),this.profilePhotoFile&&l.append("profilePhoto",this.profilePhotoFile),this.idProofFile&&l.append("idProof",this.idProofFile);let c=yield this.memberService.processMember(l,this.memberId);if(c?.data?.code===1)yield N.default.fire("Updated!",c.data.message,"success"),this.router.navigate(["/members"]);else throw new Error(c?.data?.message||"Failed to update member")}catch{yield this.showError("An error occurred while updating the member.")}finally{this.loading=!1}})}onCancel(){this.router.navigate(["/members"])}isFieldInvalid(l){let c=this.memberForm.get(l);return!!(c&&c.invalid&&(c.dirty||c.touched||this.submitted))}getErrorMessage(l){let c=this.memberForm.get(l);return!c||!c.errors?"":c.errors.required?"This field is required":c.errors.email?"Please enter a valid email address":c.errors.pattern&&l.includes("Phone")?"Please enter a valid 10-digit phone number":c.errors.minlength?`Minimum length is ${c.errors.minlength.requiredLength} characters`:"Invalid input"}showError(l){return b(this,null,function*(){yield N.default.fire({title:"Error",text:l,icon:"error"})})}};d.\u0275fac=function(c){return new(c||d)(_(ae),_(T),_(U),_(me))},d.\u0275cmp=M({type:d,selectors:[["app-update-members"]],standalone:!0,features:[w],decls:286,vars:46,consts:[["xs","12"],[1,"mb-4"],["cForm","",1,"row","g-3","needs-validation",3,"ngSubmit","formGroup"],["md","6",3,"cFormFloating"],["cFormControl","","id","firstName","formControlName","firstName","required","","type","text","placeholder","First Name"],["cLabel","","for","firstName",1,"ms-2"],[3,"valid",4,"ngIf"],["cFormControl","","id","lastName","formControlName","lastName","required","","type","text","placeholder","Last Name"],["cLabel","","for","lastName",1,"ms-2"],["cFormControl","","id","email","formControlName","email","required","","type","email","placeholder","Email"],["cLabel","","for","email",1,"ms-2"],["cFormControl","","id","phoneNumber","formControlName","phoneNumber","required","","type","tel","placeholder","Phone Number"],["cLabel","","for","phoneNumber",1,"ms-2"],["cFormControl","","id","alternatePhoneNumber","formControlName","alternatePhoneNumber","type","tel","placeholder","Alternate Phone Number"],["cLabel","","for","alternatePhoneNumber",1,"ms-2"],["cFormControl","","id","dateOfBirth","formControlName","dateOfBirth","required","","type","date","placeholder","Date of Birth"],["cLabel","","for","dateOfBirth",1,"ms-2"],["cSelect","","id","gender","formControlName","gender","required",""],["value",""],[3,"value",4,"ngFor","ngForOf"],["cLabel","","for","gender",1,"ms-2"],["cSelect","","id","nationality","formControlName","nationality","required",""],["cLabel","","for","nationality",1,"ms-2"],["md","12",3,"cFormFloating"],["cFormControl","","id","address","formControlName","address","required","","placeholder","Address","rows","3"],["cLabel","","for","address",1,"ms-2"],["cSelect","","id","plan","formControlName","plan","required",""],["cLabel","","for","plan",1,"ms-2"],["cFormControl","","id","golfClubId","formControlName","golfClubId","readonly","","type","text","placeholder","Golf Club ID"],["cLabel","","for","golfClubId",1,"ms-2"],["cFormControl","","id","membershipStartDate","formControlName","membershipStartDate","required","","type","date","placeholder","Membership Start Date"],["cLabel","","for","membershipStartDate",1,"ms-2"],["cFormControl","","id","membershipEndDate","formControlName","membershipEndDate","type","date","placeholder","Membership End Date"],["cLabel","","for","membershipEndDate",1,"ms-2"],["cSelect","","id","paymentStatus","formControlName","paymentStatus","required",""],["cLabel","","for","paymentStatus",1,"ms-2"],["cSelect","","id","paymentMethod","formControlName","paymentMethod","required",""],["cLabel","","for","paymentMethod",1,"ms-2"],["cFormControl","","id","emergencyContactName","formControlName","emergencyContactName","required","","type","text","placeholder","Emergency Contact Name"],["cLabel","","for","emergencyContactName",1,"ms-2"],["cFormControl","","id","emergencyContactPhone","formControlName","emergencyContactPhone","required","","type","tel","placeholder","Emergency Contact Phone"],["cLabel","","for","emergencyContactPhone",1,"ms-2"],["cFormControl","","id","emergencyContactRelation","formControlName","emergencyContactRelation","required","","type","text","placeholder","Relationship"],["cLabel","","for","emergencyContactRelation",1,"ms-2"],["cFormControl","","id","referredBy","formControlName","referredBy","type","text","placeholder","Referred By"],["cLabel","","for","referredBy",1,"ms-2"],["md","6"],[1,"mb-3"],["cLabel","","for","profilePhoto",1,"form-label"],["cFormControl","","type","file","id","profilePhoto","accept","image/*",1,"form-control",3,"change"],["class","mt-2",4,"ngIf"],["cLabel","","for","idProof",1,"form-label"],["cFormControl","","type","file","id","idProof","accept",".pdf,.jpg,.jpeg,.png",1,"form-control",3,"change"],[1,"form-check","mt-3"],["type","checkbox","id","handicap","formControlName","handicap",1,"form-check-input"],["for","handicap",1,"form-check-label"],["xs","12",1,"mt-4"],["cButton","","color","primary","type","submit",1,"me-2",3,"disabled"],["cButton","","color","secondary","type","button",3,"click","disabled"],[3,"valid"],[3,"value"],[1,"mt-2"],["alt","Profile Preview",1,"img-thumbnail",2,"max-width","200px","max-height","200px",3,"src"],["cButton","","color","danger","size","sm","type","button",1,"ms-2",3,"click"],[4,"ngIf"],["alt","ID Proof Preview",1,"img-thumbnail",2,"max-width","200px","max-height","200px",3,"src"],[1,"alert","alert-info"]],template:function(c,r){c&1&&(t(0,"c-row"),e(1,`
  `),t(2,"c-col",0),e(3,`
    `),t(4,"c-card",1),e(5,`
      `),t(6,"c-card-header"),e(7,`
        `),t(8,"strong"),e(9,"Update Member Profile"),i(),e(10,`
      `),i(),e(11,`
      `),t(12,"c-card-body"),e(13,`
        `),t(14,"form",2),y("ngSubmit",function(){return r.onSubmit()}),e(15,`
          `),e(16,`
          `),t(17,"c-col",3),e(18,`
            `),u(19,"input",4),e(20,`
            `),t(21,"label",5),e(22,"First Name"),i(),e(23,`
            `),s(24,xe,2,2,"c-form-feedback",6),e(25,`
          `),i(),e(26,`

          `),t(27,"c-col",3),e(28,`
            `),u(29,"input",7),e(30,`
            `),t(31,"label",8),e(32,"Last Name"),i(),e(33,`
            `),s(34,ue,2,2,"c-form-feedback",6),e(35,`
          `),i(),e(36,`

          `),t(37,"c-col",3),e(38,`
            `),u(39,"input",9),e(40,`
            `),t(41,"label",10),e(42,"Email"),i(),e(43,`
            `),s(44,he,2,2,"c-form-feedback",6),e(45,`
          `),i(),e(46,`

          `),t(47,"c-col",3),e(48,`
            `),u(49,"input",11),e(50,`
            `),t(51,"label",12),e(52,"Phone Number"),i(),e(53,`
            `),s(54,be,2,2,"c-form-feedback",6),e(55,`
          `),i(),e(56,`

          `),t(57,"c-col",3),e(58,`
            `),u(59,"input",13),e(60,`
            `),t(61,"label",14),e(62,"Alternate Phone Number"),i(),e(63,`
            `),s(64,ge,2,2,"c-form-feedback",6),e(65,`
          `),i(),e(66,`

          `),t(67,"c-col",3),e(68,`
            `),u(69,"input",15),e(70,`
            `),t(71,"label",16),e(72,"Date of Birth"),i(),e(73,`
            `),s(74,ye,2,2,"c-form-feedback",6),e(75,`
          `),i(),e(76,`

          `),t(77,"c-col",3),e(78,`
            `),t(79,"select",17),e(80,`
              `),t(81,"option",18),e(82,"Select Gender"),i(),e(83,`
              `),s(84,ve,2,2,"option",19),e(85,`
            `),i(),e(86,`
            `),t(87,"label",20),e(88,"Gender"),i(),e(89,`
            `),s(90,_e,2,2,"c-form-feedback",6),e(91,`
          `),i(),e(92,`

          `),t(93,"c-col",3),e(94,`
            `),t(95,"select",21),e(96,`
              `),t(97,"option",18),e(98,"Select Nationality"),i(),e(99,`
              `),s(100,Se,2,2,"option",19),e(101,`
            `),i(),e(102,`
            `),t(103,"label",22),e(104,"Nationality"),i(),e(105,`
            `),s(106,Ce,2,2,"c-form-feedback",6),e(107,`
          `),i(),e(108,`

          `),t(109,"c-col",23),e(110,`
            `),u(111,"textarea",24),e(112,`
            `),t(113,"label",25),e(114,"Address"),i(),e(115,`
            `),s(116,Fe,2,2,"c-form-feedback",6),e(117,`
          `),i(),e(118,`

          `),t(119,"c-col",3),e(120,`
            `),t(121,"select",26),e(122,`
              `),t(123,"option",18),e(124,"Select Plan"),i(),e(125,`
              `),s(126,Ee,2,2,"option",19),e(127,`
            `),i(),e(128,`
            `),t(129,"label",27),e(130,"Membership Plan"),i(),e(131,`
            `),s(132,Pe,2,2,"c-form-feedback",6),e(133,`
          `),i(),e(134,`

          `),t(135,"c-col",3),e(136,`
            `),u(137,"input",28),e(138,`
            `),t(139,"label",29),e(140,"Golf Club ID"),i(),e(141,`
          `),i(),e(142,`

          `),t(143,"c-col",3),e(144,`
            `),u(145,"input",30),e(146,`
            `),t(147,"label",31),e(148,"Membership Start Date"),i(),e(149,`
            `),s(150,Ie,2,2,"c-form-feedback",6),e(151,`
          `),i(),e(152,`

          `),t(153,"c-col",3),e(154,`
            `),u(155,"input",32),e(156,`
            `),t(157,"label",33),e(158,"Membership End Date"),i(),e(159,`
          `),i(),e(160,`

          `),e(161,`
          `),t(162,"c-col",3),e(163,`
            `),t(164,"select",34),e(165,`
              `),t(166,"option",18),e(167,"Select Payment Status"),i(),e(168,`
              `),s(169,Ne,2,2,"option",19),e(170,`
            `),i(),e(171,`
            `),t(172,"label",35),e(173,"Payment Status"),i(),e(174,`
            `),s(175,Me,2,2,"c-form-feedback",6),e(176,`
          `),i(),e(177,`

          `),t(178,"c-col",3),e(179,`
            `),t(180,"select",36),e(181,`
              `),t(182,"option",18),e(183,"Select Payment Method"),i(),e(184,`
              `),s(185,we,2,2,"option",19),e(186,`
            `),i(),e(187,`
            `),t(188,"label",37),e(189,"Payment Method"),i(),e(190,`
            `),s(191,ke,2,2,"c-form-feedback",6),e(192,`
          `),i(),e(193,`

          `),e(194,`
          `),t(195,"c-col",3),e(196,`
            `),u(197,"input",38),e(198,`
            `),t(199,"label",39),e(200,"Emergency Contact Name"),i(),e(201,`
            `),s(202,De,2,2,"c-form-feedback",6),e(203,`
          `),i(),e(204,`

          `),t(205,"c-col",3),e(206,`
            `),u(207,"input",40),e(208,`
            `),t(209,"label",41),e(210,"Emergency Contact Phone"),i(),e(211,`
            `),s(212,Le,2,2,"c-form-feedback",6),e(213,`
          `),i(),e(214,`

          `),t(215,"c-col",3),e(216,`
            `),u(217,"input",42),e(218,`
            `),t(219,"label",43),e(220,"Relationship"),i(),e(221,`
            `),s(222,Ue,2,2,"c-form-feedback",6),e(223,`
          `),i(),e(224,`

          `),t(225,"c-col",3),e(226,`
            `),u(227,"input",44),e(228,`
            `),t(229,"label",45),e(230,"Referred By (Optional)"),i(),e(231,`
          `),i(),e(232,`

          `),e(233,`
          `),t(234,"c-col",46),e(235,`
            `),t(236,"div",47),e(237,`
              `),t(238,"label",48),e(239,"Profile Photo"),i(),e(240,`
              `),t(241,"input",49),y("change",function(v){return r.onFileSelected(v,"profile")}),i(),e(242,`
              `),s(243,Te,7,1,"div",50),e(244,`
            `),i(),e(245,`
          `),i(),e(246,`

          `),t(247,"c-col",46),e(248,`
            `),t(249,"div",47),e(250,`
              `),t(251,"label",51),e(252,"ID Proof"),i(),e(253,`
              `),t(254,"input",52),y("change",function(v){return r.onFileSelected(v,"idProof")}),i(),e(255,`
              `),s(256,Oe,9,2,"div",50),e(257,`
            `),i(),e(258,`
          `),i(),e(259,`

          `),e(260,`
          `),t(261,"c-col",46),e(262,`
            `),t(263,"div",53),e(264,`
              `),u(265,"input",54),e(266,`
              `),t(267,"label",55),e(268,`
                Handicap
              `),i(),e(269,`
            `),i(),e(270,`
          `),i(),e(271,`

          `),e(272,`
          `),t(273,"c-col",56),e(274,`
            `),t(275,"button",57),e(276),i(),e(277,`
            `),t(278,"button",58),y("click",function(){return r.onCancel()}),e(279,`
              Cancel
            `),i(),e(280,`
          `),i(),e(281,`
        `),i(),e(282,`
      `),i(),e(283,`
    `),i(),e(284,`
  `),i(),e(285,`
`),i()),c&2&&(a(14),o("formGroup",r.memberForm),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("firstName")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("lastName")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("email")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("phoneNumber")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("alternatePhoneNumber")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("dateOfBirth")),a(3),o("cFormFloating",!0),a(7),o("ngForOf",r.genders),a(6),o("ngIf",r.isFieldInvalid("gender")),a(3),o("cFormFloating",!0),a(7),o("ngForOf",r.nationalities),a(6),o("ngIf",r.isFieldInvalid("nationality")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("address")),a(3),o("cFormFloating",!0),a(7),o("ngForOf",r.plans),a(6),o("ngIf",r.isFieldInvalid("plan")),a(3),o("cFormFloating",!0),a(8),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("membershipStartDate")),a(3),o("cFormFloating",!0),a(9),o("cFormFloating",!0),a(7),o("ngForOf",r.paymentStatuses),a(6),o("ngIf",r.isFieldInvalid("paymentStatus")),a(3),o("cFormFloating",!0),a(7),o("ngForOf",r.paymentMethods),a(6),o("ngIf",r.isFieldInvalid("paymentMethod")),a(4),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("emergencyContactName")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("emergencyContactPhone")),a(3),o("cFormFloating",!0),a(7),o("ngIf",r.isFieldInvalid("emergencyContactRelation")),a(3),o("cFormFloating",!0),a(18),o("ngIf",r.profilePhotoPreview),a(13),o("ngIf",r.idProofPreview),a(19),o("disabled",r.loading),a(),p(`
              `,r.loading?"Saving...":"Update Member Profile",`
            `),a(2),o("disabled",r.loading))},dependencies:[D,L,k,J,H,B,z,R,O,le,Y,ie,ne,Q,K,te,W,X,re,Z,ee,oe,V,$,j,A,G,q]});let n=d;return n})();export{Qe as UpdateMembersComponent};
