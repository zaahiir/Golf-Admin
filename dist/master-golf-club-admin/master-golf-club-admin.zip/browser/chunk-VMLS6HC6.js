import"./chunk-AAPNLDO3.js";var a=[{path:"",loadComponent:()=>import("./chunk-SB6HHMSO.js").then(o=>o.DashboardComponent),data:{title:$localize`Dashboard`}}];export{a as dashboardRoutes};
